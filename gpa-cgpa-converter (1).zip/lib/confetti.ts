export function createConfetti(element: HTMLElement) {
  const colors = ["#0ea5e9", "#3b82f6", "#8b5cf6", "#ec4899", "#f43f5e"]
  const confettiCount = 100
  const container = element

  // Create confetti pieces
  for (let i = 0; i < confettiCount; i++) {
    const confetti = document.createElement("div")
    confetti.className = "confetti"
    confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)]
    confetti.style.left = `${Math.random() * 100}%`
    confetti.style.top = `${Math.random() * 100}%`
    confetti.style.width = `${Math.random() * 10 + 5}px`
    confetti.style.height = `${Math.random() * 10 + 5}px`
    confetti.style.opacity = "0"
    confetti.style.transform = `rotate(${Math.random() * 360}deg)`
    confetti.style.borderRadius = Math.random() > 0.5 ? "50%" : "0"
    confetti.style.position = "absolute"

    container.appendChild(confetti)

    // Animate each piece
    setTimeout(() => {
      confetti.style.transition = `all ${Math.random() * 3 + 1}s ease-out`
      confetti.style.opacity = "1"
      confetti.style.transform = `translateY(${Math.random() * 200 - 150}px) translateX(${Math.random() * 200 - 100}px) rotate(${Math.random() * 360}deg)`
    }, Math.random() * 500)

    // Remove after animation
    setTimeout(
      () => {
        confetti.style.opacity = "0"
        setTimeout(() => {
          if (confetti.parentNode === container) {
            container.removeChild(confetti)
          }
        }, 2000)
      },
      Math.random() * 3000 + 1000,
    )
  }
}

