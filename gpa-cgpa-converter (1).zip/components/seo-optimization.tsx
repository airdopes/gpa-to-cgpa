"use client"

import Head from "next/head"
import { useRouter } from "next/router"

interface SEOProps {
  title?: string
  description?: string
  keywords?: string
  ogImage?: string
  ogType?: string
  twitterCard?: string
}

export default function SEO({
  title = "GPA to CGPA Converter | Accurate & Instant Conversion",
  description = "Convert your GPA to CGPA instantly with our accurate converter tool. Support for 4.0, 5.0, 10.0, and 20.0 grading scales with advanced visualization.",
  keywords = "GPA, CGPA, GPA to CGPA, grade converter, academic grades, university grades, college grades",
  ogImage = "/og-image.jpg",
  ogType = "website",
  twitterCard = "summary_large_image",
}: SEOProps) {
  const router = useRouter()
  const canonicalUrl = `https://gpa2cgpa.com${router.asPath}`

  return (
    <Head>
      {/* Basic Meta Tags */}
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />

      {/* Canonical Link */}
      <link rel="canonical" href={canonicalUrl} />

      {/* Open Graph / Facebook */}
      <meta property="og:type" content={ogType} />
      <meta property="og:url" content={canonicalUrl} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={ogImage} />

      {/* Twitter */}
      <meta name="twitter:card" content={twitterCard} />
      <meta name="twitter:url" content={canonicalUrl} />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={ogImage} />

      {/* Additional SEO Tags */}
      <meta name="robots" content="index, follow" />
      <meta name="author" content="GPA2CGPA" />
      <meta name="language" content="English" />

      {/* Structured Data / JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebApplication",
            name: "GPA to CGPA Converter",
            url: "https://gpa2cgpa.com",
            description: description,
            applicationCategory: "EducationalApplication",
            operatingSystem: "All",
            offers: {
              "@type": "Offer",
              price: "0",
              priceCurrency: "USD",
            },
            author: {
              "@type": "Organization",
              name: "GPA2CGPA",
              url: "https://gpa2cgpa.com",
            },
          }),
        }}
      />
    </Head>
  )
}

