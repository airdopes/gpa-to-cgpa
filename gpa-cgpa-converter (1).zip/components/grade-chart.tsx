"use client"

import { useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"

interface GradeChartProps {
  fromScale: number
  toScale: number
  fromValue: number
  toValue: number
}

export function GradeChart({ fromScale, toScale, fromValue, toValue }: GradeChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    // Clear canvas
    ctx.clearRect(0, 0, rect.width, rect.height)

    // Set chart dimensions
    const padding = 40
    const chartWidth = rect.width - padding * 2
    const chartHeight = rect.height - padding * 2

    // Draw axes
    ctx.beginPath()
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, rect.height - padding)
    ctx.lineTo(rect.width - padding, rect.height - padding)
    ctx.strokeStyle = "#94a3b8"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw grid lines
    ctx.beginPath()
    ctx.strokeStyle = "#e2e8f0"
    ctx.lineWidth = 1

    // Horizontal grid lines
    const yStep = chartHeight / 5
    for (let i = 1; i <= 5; i++) {
      const y = padding + i * yStep
      ctx.moveTo(padding, y)
      ctx.lineTo(rect.width - padding, y)
    }

    // Vertical grid lines
    const xStep = chartWidth / 5
    for (let i = 1; i <= 5; i++) {
      const x = padding + i * xStep
      ctx.moveTo(x, padding)
      ctx.lineTo(x, rect.height - padding)
    }

    ctx.stroke()

    // Draw labels
    ctx.fillStyle = "#64748b"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "center"

    // X-axis labels
    for (let i = 0; i <= 5; i++) {
      const x = padding + i * xStep
      const value = ((i * fromScale) / 5).toFixed(1)
      ctx.fillText(value, x, rect.height - padding + 20)
    }

    // Y-axis labels
    ctx.textAlign = "right"
    for (let i = 0; i <= 5; i++) {
      const y = rect.height - padding - i * yStep
      const value = ((i * toScale) / 5).toFixed(1)
      ctx.fillText(value, padding - 10, y + 5)
    }

    // Axis titles
    ctx.font = "14px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText(`GPA (${fromScale.toFixed(1)} scale)`, rect.width / 2, rect.height - 10)

    ctx.save()
    ctx.translate(15, rect.height / 2)
    ctx.rotate(-Math.PI / 2)
    ctx.fillText(`CGPA (${toScale.toFixed(1)} scale)`, 0, 0)
    ctx.restore()

    // Draw conversion line
    ctx.beginPath()
    ctx.moveTo(padding, rect.height - padding)
    ctx.lineTo(rect.width - padding, padding)
    ctx.strokeStyle = "#0ea5e9"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw point for current conversion
    const pointX = padding + (fromValue / fromScale) * chartWidth
    const pointY = rect.height - padding - (toValue / toScale) * chartHeight

    // Draw point shadow
    ctx.beginPath()
    ctx.arc(pointX, pointY, 8, 0, Math.PI * 2)
    ctx.fillStyle = "rgba(14, 165, 233, 0.3)"
    ctx.fill()

    // Draw point
    ctx.beginPath()
    ctx.arc(pointX, pointY, 6, 0, Math.PI * 2)
    ctx.fillStyle = "#0ea5e9"
    ctx.fill()
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw value labels for the point
    ctx.fillStyle = "#0f172a"
    ctx.font = "bold 12px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText(`(${fromValue.toFixed(2)}, ${toValue.toFixed(2)})`, pointX, pointY - 15)
  }, [fromScale, toScale, fromValue, toValue])

  return (
    <Card className="w-full h-full p-2 overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full" style={{ display: "block" }} />
    </Card>
  )
}

