"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Share2, RefreshCw, AlertCircle, Save, Download, Copy, Check, Info } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Slider } from "@/components/ui/slider"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { GradeChart } from "@/components/grade-chart"
import { createConfetti } from "@/lib/confetti"

export default function GpaConverter() {
  const [fromScale, setFromScale] = useState("4.0")
  const [toScale, setToScale] = useState("10.0")
  const [gpaValue, setGpaValue] = useState("")
  const [result, setResult] = useState<number | null>(null)
  const [error, setError] = useState("")
  const [isCalculating, setIsCalculating] = useState(false)
  const [activeTab, setActiveTab] = useState("simple")
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false)
  const [precision, setPrecision] = useState(2)
  const [copied, setCopied] = useState(false)
  const [conversionHistory, setConversionHistory] = useState<
    Array<{
      from: string
      to: string
      input: string
      output: number
      date: Date
    }>
  >([])
  const [showHistory, setShowHistory] = useState(false)
  const [progress, setProgress] = useState(0)
  const [showChart, setShowChart] = useState(false)
  const resultRef = useRef<HTMLDivElement>(null)

  // Advanced options
  const [useCustomFormula, setUseCustomFormula] = useState(false)
  const [customMultiplier, setCustomMultiplier] = useState("2.5")
  const [customOffset, setCustomOffset] = useState("0")

  // Batch conversion
  const [batchInput, setBatchInput] = useState("")
  const [batchResults, setBatchResults] = useState<
    Array<{
      input: string
      output: number
    }>
  >([])

  // Animation for progress bar during calculation
  useEffect(() => {
    if (isCalculating) {
      const timer = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(timer)
            return 100
          }
          return prev + 10
        })
      }, 80)

      return () => {
        clearInterval(timer)
      }
    } else {
      setProgress(0)
    }
  }, [isCalculating])

  // Reset copied state after 2 seconds
  useEffect(() => {
    if (copied) {
      const timer = setTimeout(() => {
        setCopied(false)
      }, 2000)

      return () => {
        clearTimeout(timer)
      }
    }
  }, [copied])

  const handleConvert = () => {
    setError("")
    setResult(null)

    // Validate input
    const gpa = Number.parseFloat(gpaValue)
    if (isNaN(gpa)) {
      setError("Please enter a valid GPA value")
      return
    }

    // Validate GPA is within range
    const maxGpa = Number.parseFloat(fromScale)
    if (gpa < 0 || gpa > maxGpa) {
      setError(`GPA must be between 0 and ${maxGpa}`)
      return
    }

    // Simulate calculation with loading state
    setIsCalculating(true)
    setTimeout(() => {
      // Convert GPA to CGPA
      let convertedValue

      if (useCustomFormula) {
        // Use custom formula: (gpa * multiplier) + offset
        const multiplier = Number.parseFloat(customMultiplier)
        const offset = Number.parseFloat(customOffset)
        convertedValue = gpa * multiplier + offset
      } else {
        // Standard conversion
        const fromScaleNum = Number.parseFloat(fromScale)
        const toScaleNum = Number.parseFloat(toScale)
        convertedValue = (gpa / fromScaleNum) * toScaleNum
      }

      // Apply precision
      const finalResult = Number.parseFloat(convertedValue.toFixed(precision))

      setResult(finalResult)
      setIsCalculating(false)

      // Add to history
      const newHistoryItem = {
        from: fromScale,
        to: toScale,
        input: gpaValue,
        output: finalResult,
        date: new Date(),
      }

      setConversionHistory((prev) => [newHistoryItem, ...prev].slice(0, 10))

      // Show confetti animation for successful conversion
      if (resultRef.current) {
        createConfetti(resultRef.current)
      }
    }, 1500)
  }

  const handleBatchConvert = () => {
    setError("")
    setBatchResults([])

    // Split input by new lines
    const lines = batchInput.split("\n").filter((line) => line.trim() !== "")

    if (lines.length === 0) {
      setError("Please enter at least one GPA value")
      return
    }

    // Validate all inputs
    const invalidLines = lines.filter((line) => {
      const gpa = Number.parseFloat(line)
      return isNaN(gpa) || gpa < 0 || gpa > Number.parseFloat(fromScale)
    })

    if (invalidLines.length > 0) {
      setError(`Some GPA values are invalid. All values must be between 0 and ${fromScale}`)
      return
    }

    // Simulate calculation with loading state
    setIsCalculating(true)
    setTimeout(() => {
      // Convert all GPAs
      const results = lines.map((line) => {
        const gpa = Number.parseFloat(line)
        let convertedValue

        if (useCustomFormula) {
          const multiplier = Number.parseFloat(customMultiplier)
          const offset = Number.parseFloat(customOffset)
          convertedValue = gpa * multiplier + offset
        } else {
          const fromScaleNum = Number.parseFloat(fromScale)
          const toScaleNum = Number.parseFloat(toScale)
          convertedValue = (gpa / fromScaleNum) * toScaleNum
        }

        return {
          input: line,
          output: Number.parseFloat(convertedValue.toFixed(precision)),
        }
      })

      setBatchResults(results)
      setIsCalculating(false)
    }, 2000)
  }

  const handleReset = () => {
    setGpaValue("")
    setResult(null)
    setError("")
    setBatchInput("")
    setBatchResults([])
    setShowChart(false)
  }

  const handleShare = () => {
    if (result) {
      // Create share text
      const shareText = `I converted ${gpaValue} GPA (${fromScale} scale) to ${result} CGPA (${toScale} scale) using GPA2CGPA!`

      // Check if Web Share API is available
      if (navigator.share) {
        navigator
          .share({
            title: "GPA to CGPA Conversion Result",
            text: shareText,
            url: window.location.href,
          })
          .catch((error) => console.log("Error sharing", error))
      } else {
        // Fallback to copying to clipboard
        navigator.clipboard
          .writeText(shareText)
          .then(() => {
            setCopied(true)
          })
          .catch((err) => {
            console.error("Failed to copy: ", err)
          })
      }
    }
  }

  const handleCopyResult = () => {
    if (result) {
      navigator.clipboard
        .writeText(result.toString())
        .then(() => {
          setCopied(true)
        })
        .catch((err) => {
          console.error("Failed to copy: ", err)
        })
    }
  }

  const handleSaveHistory = () => {
    if (conversionHistory.length > 0) {
      const historyData = JSON.stringify(conversionHistory)
      const blob = new Blob([historyData], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = "gpa-conversion-history.json"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }
  }

  const getLetterGrade = (gpa: number, scale: string) => {
    const scaleNum = Number.parseFloat(scale)
    const percentage = (gpa / scaleNum) * 100

    if (percentage >= 90) return "A"
    if (percentage >= 80) return "B"
    if (percentage >= 70) return "C"
    if (percentage >= 60) return "D"
    return "F"
  }

  return (
    <Card className="w-full border-2 shadow-lg transition-all duration-300 hover:shadow-xl">
      <CardHeader className="bg-gradient-to-r from-theme-700 to-theme-600 text-white rounded-t-lg">
        <CardTitle className="text-2xl font-bold">GPA to CGPA Converter</CardTitle>
        <CardDescription className="text-white/80">
          Convert your GPA to CGPA across different grading scales with precision
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        {error && (
          <Alert variant="destructive" className="animate-slide-up">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="simple" className="text-sm">
              Simple Conversion
            </TabsTrigger>
            <TabsTrigger value="batch" className="text-sm">
              Batch Conversion
            </TabsTrigger>
          </TabsList>

          <TabsContent value="simple" className="space-y-6 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="from-scale" className="text-sm font-medium">
                  From Scale
                </Label>
                <Select value={fromScale} onValueChange={setFromScale}>
                  <SelectTrigger id="from-scale" className="w-full">
                    <SelectValue placeholder="Select scale" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="4.0">4.0 Scale (US)</SelectItem>
                    <SelectItem value="5.0">5.0 Scale (Nigeria)</SelectItem>
                    <SelectItem value="10.0">10.0 Scale (India)</SelectItem>
                    <SelectItem value="20.0">20.0 Scale (France)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="to-scale" className="text-sm font-medium">
                  To Scale
                </Label>
                <Select value={toScale} onValueChange={setToScale}>
                  <SelectTrigger id="to-scale" className="w-full">
                    <SelectValue placeholder="Select scale" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="4.0">4.0 Scale (US)</SelectItem>
                    <SelectItem value="5.0">5.0 Scale (Nigeria)</SelectItem>
                    <SelectItem value="10.0">10.0 Scale (India)</SelectItem>
                    <SelectItem value="20.0">20.0 Scale (France)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="gpa-value" className="text-sm font-medium">
                  Enter your GPA
                </Label>
                <Badge variant="outline" className="text-xs">
                  Range: 0-{fromScale}
                </Badge>
              </div>
              <Input
                id="gpa-value"
                type="number"
                placeholder={`Enter your GPA (0-${fromScale})`}
                value={gpaValue}
                onChange={(e) => setGpaValue(e.target.value)}
                step="0.01"
                min="0"
                max={fromScale}
                className="transition-all duration-300 focus:ring-2 focus:ring-theme-500 focus:border-theme-500"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch id="advanced-options" checked={showAdvancedOptions} onCheckedChange={setShowAdvancedOptions} />
              <Label htmlFor="advanced-options" className="text-sm cursor-pointer">
                Show Advanced Options
              </Label>
            </div>

            {showAdvancedOptions && (
              <div className="space-y-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg animate-slide-down">
                <div className="flex items-center space-x-2">
                  <Switch id="custom-formula" checked={useCustomFormula} onCheckedChange={setUseCustomFormula} />
                  <Label htmlFor="custom-formula" className="text-sm cursor-pointer">
                    Use Custom Formula
                  </Label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="h-4 w-4 text-gray-400" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs">Custom formula: (GPA × Multiplier) + Offset</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>

                {useCustomFormula && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in">
                    <div className="space-y-2">
                      <Label htmlFor="custom-multiplier" className="text-sm">
                        Multiplier
                      </Label>
                      <Input
                        id="custom-multiplier"
                        type="number"
                        value={customMultiplier}
                        onChange={(e) => setCustomMultiplier(e.target.value)}
                        step="0.1"
                        className="text-sm"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="custom-offset" className="text-sm">
                        Offset
                      </Label>
                      <Input
                        id="custom-offset"
                        type="number"
                        value={customOffset}
                        onChange={(e) => setCustomOffset(e.target.value)}
                        step="0.1"
                        className="text-sm"
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="precision" className="text-sm">
                      Decimal Precision: {precision}
                    </Label>
                  </div>
                  <Slider
                    id="precision"
                    min={0}
                    max={4}
                    step={1}
                    value={[precision]}
                    onValueChange={(value) => setPrecision(value[0])}
                    className="w-full"
                  />
                </div>
              </div>
            )}

            {isCalculating && (
              <div className="space-y-2 animate-pulse">
                <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                  <span>Calculating...</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="w-full h-2" />
              </div>
            )}

            {result !== null && (
              <div
                ref={resultRef}
                className="p-6 bg-gradient-to-r from-theme-50 to-theme-100 dark:from-theme-900/30 dark:to-theme-800/30 rounded-lg text-center animate-fade-in relative overflow-hidden"
              >
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Your converted CGPA is:</p>
                    <p className="text-4xl font-bold text-theme-600 dark:text-theme-400 mt-1">{result}</p>
                    <div className="flex justify-center mt-2">
                      <Badge className="bg-theme-500 hover:bg-theme-600">{getLetterGrade(result, toScale)} Grade</Badge>
                    </div>
                  </div>

                  <div className="text-sm text-gray-600 dark:text-gray-300 pt-2 border-t border-gray-200 dark:border-gray-700">
                    <p>
                      {gpaValue} GPA ({fromScale} scale) = {result} CGPA ({toScale} scale)
                    </p>
                  </div>

                  <div className="flex justify-center space-x-2">
                    <Button variant="outline" size="sm" onClick={handleCopyResult} className="text-xs">
                      {copied ? (
                        <>
                          <Check className="mr-1 h-3 w-3" />
                          Copied
                        </>
                      ) : (
                        <>
                          <Copy className="mr-1 h-3 w-3" />
                          Copy
                        </>
                      )}
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setShowChart(!showChart)} className="text-xs">
                      {showChart ? "Hide Chart" : "Show Chart"}
                    </Button>
                  </div>

                  {showChart && (
                    <div className="mt-4 h-64 animate-fade-in">
                      <GradeChart
                        fromScale={Number.parseFloat(fromScale)}
                        toScale={Number.parseFloat(toScale)}
                        fromValue={Number.parseFloat(gpaValue)}
                        toValue={result}
                      />
                    </div>
                  )}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="batch" className="space-y-6 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="batch-from-scale" className="text-sm font-medium">
                  From Scale
                </Label>
                <Select value={fromScale} onValueChange={setFromScale}>
                  <SelectTrigger id="batch-from-scale" className="w-full">
                    <SelectValue placeholder="Select scale" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="4.0">4.0 Scale (US)</SelectItem>
                    <SelectItem value="5.0">5.0 Scale (Nigeria)</SelectItem>
                    <SelectItem value="10.0">10.0 Scale (India)</SelectItem>
                    <SelectItem value="20.0">20.0 Scale (France)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="batch-to-scale" className="text-sm font-medium">
                  To Scale
                </Label>
                <Select value={toScale} onValueChange={setToScale}>
                  <SelectTrigger id="batch-to-scale" className="w-full">
                    <SelectValue placeholder="Select scale" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="4.0">4.0 Scale (US)</SelectItem>
                    <SelectItem value="5.0">5.0 Scale (Nigeria)</SelectItem>
                    <SelectItem value="10.0">10.0 Scale (India)</SelectItem>
                    <SelectItem value="20.0">20.0 Scale (France)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="batch-input" className="text-sm font-medium">
                  Enter multiple GPA values (one per line)
                </Label>
                <Badge variant="outline" className="text-xs">
                  Range: 0-{fromScale}
                </Badge>
              </div>
              <textarea
                id="batch-input"
                placeholder={`Enter your GPA values (0-${fromScale}), one per line\nExample:\n3.5\n3.2\n3.8`}
                value={batchInput}
                onChange={(e) => setBatchInput(e.target.value)}
                rows={5}
                className="w-full min-h-[120px] p-3 rounded-md border border-gray-300 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-theme-500 focus:border-theme-500 bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100"
              />
            </div>

            {isCalculating && (
              <div className="space-y-2 animate-pulse">
                <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                  <span>Calculating...</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="w-full h-2" />
              </div>
            )}

            {batchResults.length > 0 && (
              <div className="p-4 bg-gradient-to-r from-theme-50 to-theme-100 dark:from-theme-900/30 dark:to-theme-800/30 rounded-lg animate-fade-in">
                <h3 className="font-medium text-center mb-3">Conversion Results</h3>
                <div className="max-h-[300px] overflow-y-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-100 dark:bg-gray-800">
                      <tr>
                        <th className="p-2 text-left">GPA ({fromScale} scale)</th>
                        <th className="p-2 text-left">CGPA ({toScale} scale)</th>
                        <th className="p-2 text-left">Grade</th>
                      </tr>
                    </thead>
                    <tbody>
                      {batchResults.map((result, index) => (
                        <tr
                          key={index}
                          className={index % 2 === 0 ? "bg-white dark:bg-gray-900" : "bg-gray-50 dark:bg-gray-800/50"}
                        >
                          <td className="p-2">{result.input}</td>
                          <td className="p-2 font-medium text-theme-600 dark:text-theme-400">{result.output}</td>
                          <td className="p-2">
                            <Badge
                              size="sm"
                              variant="outline"
                              className="bg-theme-100 dark:bg-theme-900 text-theme-800 dark:text-theme-300 border-theme-200 dark:border-theme-800"
                            >
                              {getLetterGrade(result.output, toScale)}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-4 flex justify-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const csv = [
                        ["GPA", "CGPA", "Grade"],
                        ...batchResults.map((r) => [r.input, r.output.toString(), getLetterGrade(r.output, toScale)]),
                      ]
                        .map((row) => row.join(","))
                        .join("\n")

                      const blob = new Blob([csv], { type: "text/csv" })
                      const url = URL.createObjectURL(blob)
                      const a = document.createElement("a")
                      a.href = url
                      a.download = "batch-conversion-results.csv"
                      document.body.appendChild(a)
                      a.click()
                      document.body.removeChild(a)
                      URL.revokeObjectURL(url)
                    }}
                    className="text-xs"
                  >
                    <Download className="mr-1 h-3 w-3" />
                    Download CSV
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-800">
          <Button
            variant="link"
            size="sm"
            onClick={() => setShowHistory(!showHistory)}
            className="text-xs text-gray-500 dark:text-gray-400"
          >
            {showHistory ? "Hide History" : "Show History"}
          </Button>

          {conversionHistory.length > 0 && (
            <Button variant="ghost" size="sm" onClick={handleSaveHistory} className="text-xs">
              <Save className="mr-1 h-3 w-3" />
              Save History
            </Button>
          )}
        </div>

        {showHistory && conversionHistory.length > 0 && (
          <div className="border rounded-lg overflow-hidden animate-slide-up">
            <div className="bg-gray-50 dark:bg-gray-800 px-4 py-2 text-sm font-medium">Recent Conversions</div>
            <div className="max-h-[200px] overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-100 dark:bg-gray-800">
                  <tr>
                    <th className="p-2 text-left">Date</th>
                    <th className="p-2 text-left">From</th>
                    <th className="p-2 text-left">To</th>
                    <th className="p-2 text-left">Result</th>
                  </tr>
                </thead>
                <tbody>
                  {conversionHistory.map((item, index) => (
                    <tr
                      key={index}
                      className={index % 2 === 0 ? "bg-white dark:bg-gray-900" : "bg-gray-50 dark:bg-gray-800/50"}
                    >
                      <td className="p-2">{item.date.toLocaleString()}</td>
                      <td className="p-2">
                        {item.input} ({item.from})
                      </td>
                      <td className="p-2">
                        {item.output} ({item.to})
                      </td>
                      <td className="p-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0"
                          onClick={() => {
                            setFromScale(item.from)
                            setToScale(item.to)
                            setGpaValue(item.input)
                            setResult(item.output)
                            setActiveTab("simple")
                          }}
                        >
                          <RefreshCw className="h-3 w-3" />
                          <span className="sr-only">Reuse</span>
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row gap-3 bg-gray-50 dark:bg-gray-800/50 p-6 rounded-b-lg">
        <Button
          onClick={activeTab === "simple" ? handleConvert : handleBatchConvert}
          className="w-full sm:w-auto bg-theme-600 hover:bg-theme-700 text-white glow-effect"
          disabled={isCalculating || (activeTab === "simple" ? !gpaValue : !batchInput)}
        >
          {isCalculating ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Converting...
            </>
          ) : (
            "Convert"
          )}
        </Button>
        <Button variant="outline" onClick={handleReset} className="w-full sm:w-auto">
          Reset
        </Button>
        {result !== null && activeTab === "simple" && (
          <Button variant="outline" onClick={handleShare} className="w-full sm:w-auto ml-auto">
            <Share2 className="mr-2 h-4 w-4" />
            Share Result
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

