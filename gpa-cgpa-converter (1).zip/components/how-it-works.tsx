import { Card, CardContent } from "@/components/ui/card"
import { Calculator, FileText, Share2, BarChart } from "lucide-react"

export default function HowItWorks() {
  const steps = [
    {
      icon: <FileText className="h-10 w-10 text-theme-500" />,
      title: "Select Your Scales",
      description: "Choose the scale you're converting from and the scale you want to convert to.",
    },
    {
      icon: <Calculator className="h-10 w-10 text-theme-500" />,
      title: "Enter Your GPA",
      description: "Input your current GPA value that you want to convert.",
    },
    {
      icon: <BarChart className="h-10 w-10 text-theme-500" />,
      title: "View Visualization",
      description: "See your conversion results with interactive charts and grade information.",
    },
    {
      icon: <Share2 className="h-10 w-10 text-theme-500" />,
      title: "Save & Share Results",
      description: "Save your conversion history or share your results with others.",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {steps.map((step, index) => (
        <Card
          key={index}
          className="border-2 border-theme-100 dark:border-theme-900 hover:border-theme-300 dark:hover:border-theme-700 transition-colors group overflow-hidden"
        >
          <CardContent className="flex flex-col items-center text-center p-6 relative">
            {/* Step Number */}
            <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-theme-100 dark:bg-theme-900 flex items-center justify-center text-theme-600 dark:text-theme-400 font-bold text-sm group-hover:bg-theme-500 group-hover:text-white transition-colors">
              {index + 1}
            </div>

            <div className="rounded-full bg-theme-100 dark:bg-theme-900 p-4 mb-4 group-hover:bg-theme-500/20 transition-colors">
              {step.icon}
            </div>
            <h3 className="text-xl font-bold mb-2 group-hover:text-theme-600 dark:group-hover:text-theme-400 transition-colors">
              {step.title}
            </h3>
            <p className="text-gray-500 dark:text-gray-400">{step.description}</p>

            {/* Animated Arrow */}
            {index < steps.length - 1 && (
              <div className="hidden lg:block absolute -right-10 top-1/2 transform -translate-y-1/2 text-theme-300 dark:text-theme-700">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="40"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="animate-bounce-light"
                >
                  <path d="M5 12h14"></path>
                  <path d="m12 5 7 7-7 7"></path>
                </svg>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

