export const metadata = {
  title: "Terms of Service | GPA to CGPA Converter",
  description: "Our terms of service outline the rules and guidelines for using our GPA to CGPA converter tool.",
}

export default function TermsOfServicePage() {
  return (
    <div className="flex flex-col min-h-screen">
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Terms of Service
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Last updated: March 24, 2023
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-3xl space-y-8">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold">1. Introduction</h2>
              <p className="text-gray-500 dark:text-gray-400">
                Welcome to GPA2CGPA. These terms and conditions outline the rules and regulations for the use of our
                website and services.
              </p>
              <p className="text-gray-500 dark:text-gray-400">
                By accessing this website, we assume you accept these terms and conditions in full. Do not continue to
                use GPA2CGPA if you do not accept all of the terms and conditions stated on this page.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">2. License to Use</h2>
              <p className="text-gray-500 dark:text-gray-400">
                Unless otherwise stated, GPA2CGPA and/or its licensors own the intellectual property rights for all
                material on GPA2CGPA. All intellectual property rights are reserved.
              </p>
              <p className="text-gray-500 dark:text-gray-400">
                You may view and/or print pages from the website for your own personal use subject to restrictions set
                in these terms and conditions.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">3. Restrictions</h2>
              <p className="text-gray-500 dark:text-gray-400">
                You are specifically restricted from all of the following:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-500 dark:text-gray-400">
                <li>Publishing any website material in any other media</li>
                <li>Selling, sublicensing and/or otherwise commercializing any website material</li>
                <li>Publicly performing and/or showing any website material</li>
                <li>Using this website in any way that is or may be damaging to this website</li>
                <li>Using this website in any way that impacts user access to this website</li>
                <li>
                  Using this website contrary to applicable laws and regulations, or in any way may cause harm to the
                  website, or to any person or business entity
                </li>
              </ul>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">4. Your Content</h2>
              <p className="text-gray-500 dark:text-gray-400">
                In these terms and conditions, "Your Content" shall mean any audio, video, text, images or other
                material you choose to display on this website. By displaying Your Content, you grant GPA2CGPA a
                non-exclusive, worldwide, irrevocable, royalty-free, sublicensable license to use, reproduce, adapt,
                publish, translate and distribute it in any and all media.
              </p>
              <p className="text-gray-500 dark:text-gray-400">
                Your Content must be your own and must not be infringing on any third party's rights. GPA2CGPA reserves
                the right to remove any of Your Content from this website at any time without notice.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">5. No Warranties</h2>
              <p className="text-gray-500 dark:text-gray-400">
                This website is provided "as is," with all faults, and GPA2CGPA makes no express or implied
                representations or warranties, of any kind related to this website or the materials contained on this
                website.
              </p>
              <p className="text-gray-500 dark:text-gray-400">
                Additionally, nothing contained on this website shall be construed as providing advice to you.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">6. Advertisements</h2>
              <p className="text-gray-500 dark:text-gray-400">
                This website contains advertisements, including those served by Google AdSense. By using this website,
                you agree to view these advertisements as part of the service we provide.
              </p>
              <p className="text-gray-500 dark:text-gray-400">
                We are not responsible for the content of these advertisements, including but not limited to any
                products, services, or websites advertised. Any transactions or interactions with advertisers found on
                our website are solely between you and the advertiser.
              </p>
              <p className="text-gray-500 dark:text-gray-400">
                The presence of advertisements on our website does not constitute an endorsement, guarantee, warranty,
                or recommendation of the advertised products or services.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">7. Limitation of Liability</h2>
              <p className="text-gray-500 dark:text-gray-400">
                In no event shall GPA2CGPA, nor any of its officers, directors and employees, be liable to you for
                anything arising out of or in any way connected with your use of this website, whether such liability is
                under contract, tort or otherwise.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">8. Indemnification</h2>
              <p className="text-gray-500 dark:text-gray-400">
                You hereby indemnify to the fullest extent GPA2CGPA from and against any and all liabilities, costs,
                demands, causes of action, damages and expenses (including reasonable attorney's fees) arising out of or
                in any way related to your breach of any of the provisions of these terms.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">9. Severability</h2>
              <p className="text-gray-500 dark:text-gray-400">
                If any provision of these terms is found to be unenforceable or invalid under any applicable law, such
                unenforceability or invalidity shall not render these terms unenforceable or invalid as a whole, and
                such provisions shall be deleted without affecting the remaining provisions herein.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">10. Variation of Terms</h2>
              <p className="text-gray-500 dark:text-gray-400">
                GPA2CGPA is permitted to revise these terms at any time as it sees fit, and by using this website you
                are expected to review such terms on a regular basis to ensure you understand all terms and conditions
                governing use of this website.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-bold">11. Contact Us</h2>
              <p className="text-gray-500 dark:text-gray-400">
                If you have any questions about these Terms of Service, please contact us at:
              </p>
              <p className="text-gray-500 dark:text-gray-400">
                Email: legal@gpa2cgpa.com
                <br />
                Phone: +1 (234) 567-890
                <br />
                Address: 123 Education Street, Academic City, AC 12345, United States
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

