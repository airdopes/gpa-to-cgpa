import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

export const metadata = {
  title: "Blog | GPA to CGPA Converter",
  description: "Read our latest articles about GPA, CGPA, and academic success strategies.",
}

export default function BlogPage() {
  const blogPosts = [
    {
      title: "What is CGPA & How to Convert GPA to CGPA?",
      description: "Learn the difference between GPA and CGPA and how to convert between them accurately.",
      date: "March 15, 2023",
      category: "Education",
      slug: "what-is-cgpa-and-how-to-convert-gpa-to-cgpa",
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      title: "Top Universities and Their GPA Systems",
      description: "Explore different grading systems used by top universities worldwide and how they compare.",
      date: "February 28, 2023",
      category: "Universities",
      slug: "top-universities-and-their-gpa-systems",
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      title: "Tips to Improve Your GPA",
      description: "Practical strategies and study techniques to boost your academic performance and GPA.",
      date: "January 20, 2023",
      category: "Study Tips",
      slug: "tips-to-improve-your-gpa",
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      title: "Understanding Different Grading Scales Around the World",
      description: "A comprehensive guide to grading systems used in different countries and educational systems.",
      date: "December 12, 2022",
      category: "Education",
      slug: "understanding-different-grading-scales-around-the-world",
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      title: "How CGPA Affects Your Graduate School Applications",
      description: "Learn how your CGPA impacts your chances of getting into top graduate programs.",
      date: "November 5, 2022",
      category: "Graduate School",
      slug: "how-cgpa-affects-your-graduate-school-applications",
      image: "/placeholder.svg?height=400&width=600",
    },
    {
      title: "The History of Academic Grading Systems",
      description: "Explore the evolution of grading systems from their origins to modern implementations.",
      date: "October 18, 2022",
      category: "Education History",
      slug: "the-history-of-academic-grading-systems",
      image: "/placeholder.svg?height=400&width=600",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">Our Blog</h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Insights, guides, and tips about GPA, CGPA, and academic success.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Ad Space - Top */}
      <div className="container px-4 md:px-6 mt-8">
        <div className="w-full h-[120px] bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-700">
          <p className="text-gray-500 dark:text-gray-400 text-sm">Advertisement Space</p>
        </div>
      </div>

      {/* Blog Posts Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="aspect-video w-full overflow-hidden">
                  <img
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                  />
                </div>
                <CardHeader>
                  <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-2">
                    <span>{post.date}</span>
                    <span>•</span>
                    <span>{post.category}</span>
                  </div>
                  <CardTitle>{post.title}</CardTitle>
                  <CardDescription>{post.description}</CardDescription>
                </CardHeader>
                <CardFooter>
                  <Button asChild variant="outline">
                    <Link href={`/blog/${post.slug}`}>
                      Read More <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Ad Space - Middle */}
      <div className="container px-4 md:px-6 my-8">
        <div className="w-full h-[120px] bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-700">
          <p className="text-gray-500 dark:text-gray-400 text-sm">Advertisement Space</p>
        </div>
      </div>

      {/* Newsletter Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50 dark:bg-gray-900">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Subscribe to Our Newsletter</h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Get the latest articles and updates delivered to your inbox.
              </p>
            </div>
            <div className="w-full max-w-md space-y-2">
              <form className="flex space-x-2">
                <Input type="email" placeholder="Enter your email" className="flex-1" />
                <Button type="submit">Subscribe</Button>
              </form>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                We respect your privacy. Unsubscribe at any time.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

// Add this import at the top of the file
import { Input } from "@/components/ui/input"

