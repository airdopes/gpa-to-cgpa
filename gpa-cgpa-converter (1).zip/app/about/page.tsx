import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export const metadata = {
  title: "About Us | GPA to CGPA Converter",
  description:
    "Learn about our mission to provide the most accurate GPA to CGPA conversion tool for students worldwide.",
}

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                About GPA2CGPA
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Our mission is to simplify academic grade conversion for students worldwide.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Content */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tighter mb-4">Our Story</h2>
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                GPA2CGPA was founded in 2023 by a group of international students who experienced firsthand the
                challenges of understanding different grading systems across universities worldwide.
              </p>
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                We noticed that many students struggle when applying to international universities or programs because
                of the varying GPA scales used around the world. What might be an excellent grade in one system could be
                perceived differently in another.
              </p>
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                Our team of education experts and developers came together to create a simple yet powerful tool that
                accurately converts between different grading systems, helping students present their academic
                achievements accurately and confidently.
              </p>
              <p className="text-gray-500 dark:text-gray-400">
                Today, our tool is used by thousands of students across the globe, making academic transitions smoother
                and helping students achieve their educational goals.
              </p>
            </div>
            <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-8">
              <h2 className="text-3xl font-bold tracking-tighter mb-4">Our Mission</h2>
              <p className="text-gray-500 dark:text-gray-400 mb-4">At GPA2CGPA, our mission is to:</p>
              <ul className="space-y-2 text-gray-500 dark:text-gray-400 mb-4">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Provide the most accurate GPA to CGPA conversion tool available online</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Educate students about different grading systems worldwide</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Help students present their academic achievements accurately</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Make educational transitions between institutions smoother</span>
                </li>
              </ul>
              <p className="text-gray-500 dark:text-gray-400">
                We believe that understanding your grades in different contexts shouldn't be a barrier to educational
                opportunities.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50 dark:bg-gray-900">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center mb-12">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Team</h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Meet the experts behind GPA2CGPA
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {[
              {
                name: "Alex Johnson",
                role: "Founder & CEO",
                bio: "Former international student with a passion for educational technology.",
                image: "/placeholder.svg?height=300&width=300",
              },
              {
                name: "Sarah Chen",
                role: "Education Expert",
                bio: "PhD in Education Policy with 10+ years experience in international education.",
                image: "/placeholder.svg?height=300&width=300",
              },
              {
                name: "Michael Rodriguez",
                role: "Lead Developer",
                bio: "Full-stack developer specializing in educational technology solutions.",
                image: "/placeholder.svg?height=300&width=300",
              },
              {
                name: "Priya Patel",
                role: "UX Designer",
                bio: "Creating intuitive user experiences for educational tools and platforms.",
                image: "/placeholder.svg?height=300&width=300",
              },
            ].map((member, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="w-32 h-32 rounded-full overflow-hidden mb-4">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold">{member.name}</h3>
                <p className="text-primary font-medium">{member.role}</p>
                <p className="text-gray-500 dark:text-gray-400 mt-2">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Ready to Convert Your Grades?
              </h2>
              <p className="mx-auto max-w-[700px] md:text-xl">
                Try our GPA to CGPA converter now and get accurate results instantly.
              </p>
            </div>
            <div className="w-full max-w-sm space-y-2">
              <Button asChild variant="secondary" size="lg" className="w-full">
                <Link href="/#converter">
                  Convert Now <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

