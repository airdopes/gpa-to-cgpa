import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Share2, Calculator, Award, BookOpen, Sparkles } from "lucide-react"
import GpaConverter from "@/components/gpa-converter"
import HowItWorks from "@/components/how-it-works"
import { Badge } from "@/components/ui/badge"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-16 md:py-24 lg:py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-theme-900 to-theme-700 opacity-90"></div>
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1600')] bg-cover bg-center mix-blend-overlay"></div>

        {/* Animated Shapes */}
        <div className="absolute top-20 left-10 w-64 h-64 bg-theme-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-theme-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-20 left-1/3 w-80 h-80 bg-theme-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>

        <div className="container px-4 md:px-6 relative z-10">
          <div className="flex flex-col items-center space-y-8 text-center">
            <Badge className="px-4 py-2 bg-white/10 text-white backdrop-blur-sm border-white/20 animate-fade-in">
              <Sparkles className="h-4 w-4 mr-2" />
              The Most Advanced GPA to CGPA Converter
            </Badge>

            <div className="space-y-4 max-w-3xl">
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl/none text-white animate-slide-up">
                Easily Convert Your GPA to CGPA
                <span className="block text-theme-300"> – Accurate & Instant!</span>
              </h1>
              <p className="mx-auto max-w-[700px] text-white/80 md:text-xl animate-slide-up animation-delay-200">
                Our advanced tool provides instant and accurate conversion between different grading systems. Simple,
                fast, and reliable with interactive visualizations.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md animate-slide-up animation-delay-300">
              <Button asChild size="lg" className="w-full bg-white text-theme-800 hover:bg-white/90">
                <a href="#converter">
                  Try Converter <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="w-full border-white/20 text-white hover:bg-white/10"
              >
                <Link href="/about">Learn More</Link>
              </Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-3xl pt-8 animate-fade-in animation-delay-500">
              {[
                { icon: <Calculator className="h-6 w-6" />, text: "Multiple Grading Scales" },
                { icon: <Award className="h-6 w-6" />, text: "Accurate Conversions" },
                { icon: <Share2 className="h-6 w-6" />, text: "Easy Sharing" },
                { icon: <BookOpen className="h-6 w-6" />, text: "Educational Resources" },
              ].map((feature, index) => (
                <div
                  key={index}
                  className="flex flex-col items-center p-4 bg-white/10 backdrop-blur-sm rounded-lg text-white"
                >
                  {feature.icon}
                  <span className="mt-2 text-sm font-medium">{feature.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Wave Divider */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 120" className="w-full h-auto">
            <path
              fill="currentColor"
              className="text-background"
              d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z"
            ></path>
          </svg>
        </div>
      </section>

      {/* Converter Section */}
      <section id="converter" className="w-full py-16 md:py-24 lg:py-32 relative">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-8 text-center mb-12">
            <div className="inline-block p-1 bg-theme-100 dark:bg-theme-900/30 rounded-full animate-pulse-scale">
              <div className="bg-theme-500 text-white p-2 rounded-full">
                <Calculator className="h-6 w-6" />
              </div>
            </div>
            <div className="space-y-2 max-w-2xl">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">GPA to CGPA Converter</h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Convert between different grading systems with our interactive tool. Supports 4.0, 5.0, 10.0, and 20.0
                scales with advanced options.
              </p>
            </div>
            <div className="w-full max-w-4xl mx-auto">
              <GpaConverter />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="w-full py-16 md:py-24 lg:py-32 bg-gray-50 dark:bg-gray-900 relative">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-8 text-center mb-12">
            <div className="inline-block p-1 bg-theme-100 dark:bg-theme-900/30 rounded-full">
              <div className="bg-theme-500 text-white p-2 rounded-full">
                <Award className="h-6 w-6" />
              </div>
            </div>
            <div className="space-y-2 max-w-2xl">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">How It Works</h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Converting your GPA to CGPA is simple with our tool. Follow these steps:
              </p>
            </div>
            <div className="w-full max-w-4xl mx-auto">
              <HowItWorks />
            </div>
          </div>
        </div>

        {/* Diagonal Divider */}
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-background transform -skew-y-2 translate-y-8"></div>
      </section>

      {/* Ad Space */}
      <div className="container px-4 md:px-6 my-8">
        <div className="w-full h-[120px] bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-700">
          <p className="text-gray-500 dark:text-gray-400 text-sm">Advertisement Space</p>
        </div>
      </div>

      {/* Blog Preview Section */}
      <section className="w-full py-16 md:py-24 lg:py-32 relative">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-8 text-center mb-12">
            <div className="inline-block p-1 bg-theme-100 dark:bg-theme-900/30 rounded-full">
              <div className="bg-theme-500 text-white p-2 rounded-full">
                <BookOpen className="h-6 w-6" />
              </div>
            </div>
            <div className="space-y-2 max-w-2xl">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Latest Articles</h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                Learn more about GPA, CGPA, and academic success with our informative articles.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-5xl mx-auto">
              {[
                {
                  title: "What is CGPA & How to Convert GPA to CGPA?",
                  description: "Learn the difference between GPA and CGPA and how to convert between them.",
                  slug: "what-is-cgpa-and-how-to-convert-gpa-to-cgpa",
                  image: "/placeholder.svg?height=400&width=600",
                },
                {
                  title: "Top Universities and Their GPA Systems",
                  description: "Explore different grading systems used by top universities worldwide.",
                  slug: "top-universities-and-their-gpa-systems",
                  image: "/placeholder.svg?height=400&width=600",
                },
                {
                  title: "Tips to Improve Your GPA",
                  description: "Practical strategies to boost your academic performance and GPA.",
                  slug: "tips-to-improve-your-gpa",
                  image: "/placeholder.svg?height=400&width=600",
                },
              ].map((article, index) => (
                <div
                  key={index}
                  className="group relative overflow-hidden rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl card-hover"
                >
                  <div className="aspect-video w-full overflow-hidden">
                    <img
                      src={article.image || "/placeholder.svg"}
                      alt={article.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-80"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-left">
                    <h3 className="text-xl font-bold text-white mb-2">{article.title}</h3>
                    <p className="text-white/80 text-sm mb-4 line-clamp-2">{article.description}</p>
                    <Button
                      asChild
                      variant="outline"
                      size="sm"
                      className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
                    >
                      <Link href={`/blog/${article.slug}`}>
                        Read More <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <Button
              asChild
              variant="outline"
              className="mt-6 border-theme-200 text-theme-700 hover:bg-theme-50 dark:border-theme-800 dark:text-theme-300 dark:hover:bg-theme-900/50"
            >
              <Link href="/blog">
                View All Articles <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-16 md:py-24 lg:py-32 bg-gradient-to-r from-theme-700 to-theme-600 text-white relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white/10 rounded-full mix-blend-overlay filter blur-3xl opacity-30 animate-float"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white/10 rounded-full mix-blend-overlay filter blur-3xl opacity-30 animate-float animation-delay-2000"></div>
        </div>

        <div className="container px-4 md:px-6 relative z-10">
          <div className="flex flex-col items-center space-y-8 text-center">
            <div className="space-y-4 max-w-3xl">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Ready to Convert Your Grades?
              </h2>
              <p className="mx-auto max-w-[700px] md:text-xl">
                Try our GPA to CGPA converter now and get accurate results instantly. Share your results with friends or
                save them for future reference.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md">
              <Button asChild size="lg" className="w-full bg-white text-theme-800 hover:bg-white/90 glow-effect">
                <a href="#converter">
                  Convert Now <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="w-full border-white/20 text-white hover:bg-white/10"
              >
                <Link href="/about">Learn About Us</Link>
              </Button>
            </div>

            {/* Testimonials */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-5xl mt-8">
              {[
                {
                  quote: "This tool saved me so much time when applying to international universities!",
                  author: "Sarah K., Student",
                },
                {
                  quote: "The most accurate GPA converter I've found. Love the visualization features.",
                  author: "Prof. James Wilson",
                },
                {
                  quote: "Simple to use and incredibly helpful. Recommended for all students!",
                  author: "Michael T., Academic Advisor",
                },
              ].map((testimonial, index) => (
                <div key={index} className="p-6 bg-white/10 backdrop-blur-sm rounded-lg text-left">
                  <p className="italic text-white/90 mb-4">"{testimonial.quote}"</p>
                  <p className="text-sm font-medium text-white/70">— {testimonial.author}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Ad Space - Bottom */}
      <div className="container px-4 md:px-6 py-8">
        <div className="w-full h-[120px] bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300 dark:border-gray-700">
          <p className="text-gray-500 dark:text-gray-400 text-sm">Advertisement Space</p>
        </div>
      </div>
    </div>
  )
}

