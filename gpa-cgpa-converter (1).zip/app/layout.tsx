import type React from "react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { ThemeProvider } from "@/components/theme-provider"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "GPA to CGPA Converter | Accurate & Instant Conversion",
  description:
    "Convert your GPA to CGPA instantly with our accurate converter tool. Support for 4.0, 5.0, 10.0, and 20.0 grading scales with advanced visualization.",
  keywords:
    "GPA, CGPA, GPA to CGPA, grade converter, academic grades, university grades, college grades, grade calculation, GPA calculator, CGPA calculator",
  authors: [{ name: "GPA2CGPA Team" }],
  creator: "GPA2CGPA",
  publisher: "GPA2CGPA",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://gpa2cgpa.com",
    title: "GPA to CGPA Converter | Accurate & Instant Conversion",
    description:
      "Convert your GPA to CGPA instantly with our accurate converter tool. Support for multiple grading scales.",
    siteName: "GPA2CGPA",
  },
  twitter: {
    card: "summary_large_image",
    title: "GPA to CGPA Converter | Accurate & Instant Conversion",
    description:
      "Convert your GPA to CGPA instantly with our accurate converter tool. Support for multiple grading scales.",
    creator: "@gpa2cgpa",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <div className="relative flex min-h-screen flex-col">
            <SiteHeader />
            <main className="flex-1">{children}</main>
            <SiteFooter />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'