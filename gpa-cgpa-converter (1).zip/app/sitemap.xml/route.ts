import { NextResponse } from "next/server"

export async function GET() {
  // Base URL of your website
  const baseUrl = "https://gpa2cgpa.com"

  // Current date in ISO format
  const date = new Date().toISOString()

  // List of all pages
  const pages = [
    "",
    "/about",
    "/contact",
    "/blog",
    "/faq",
    "/privacy-policy",
    "/terms-of-service",
    "/blog/what-is-cgpa-and-how-to-convert-gpa-to-cgpa",
    "/blog/top-universities-and-their-gpa-systems",
    "/blog/tips-to-improve-your-gpa",
    "/blog/understanding-different-grading-scales-around-the-world",
    "/blog/how-cgpa-affects-your-graduate-school-applications",
    "/blog/the-history-of-academic-grading-systems",
  ]

  // Generate sitemap XML
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  ${pages
    .map(
      (page) => `
  <url>
    <loc>${baseUrl}${page}</loc>
    <lastmod>${date}</lastmod>
    <changefreq>${page === "" ? "daily" : "weekly"}</changefreq>
    <priority>${page === "" ? "1.0" : "0.8"}</priority>
  </url>
  `,
    )
    .join("")}
</urlset>`

  // Return the sitemap XML with appropriate headers
  return new NextResponse(sitemap, {
    headers: {
      "Content-Type": "application/xml",
      "Cache-Control": "public, max-age=86400, s-maxage=86400",
    },
  })
}

