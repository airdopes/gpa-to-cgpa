import type { Metadata } from "next"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export const metadata: Metadata = {
  title: "Frequently Asked Questions | GPA to CGPA Converter",
  description:
    "Find answers to common questions about GPA to CGPA conversion, grading scales, and how to use our converter tool.",
  keywords: "GPA FAQ, CGPA questions, GPA conversion help, grading scale questions, academic grading FAQ",
}

export default function FAQPage() {
  const faqItems = [
    {
      question: "What is the difference between GPA and CGPA?",
      answer:
        "GPA (Grade Point Average) typically refers to the average grade points earned in a specific semester or term. CGPA (Cumulative Grade Point Average) represents the average grade points earned across all semesters or terms throughout your academic program.",
    },
    {
      question: "How is GPA calculated?",
      answer:
        "GPA is calculated by dividing the total number of grade points earned by the total number of credit hours attempted. The formula is: GPA = Total Grade Points ÷ Total Credit Hours. Different institutions may use different scales (4.0, 5.0, 10.0, etc.) for calculating GPA.",
    },
    {
      question: "How accurate is your GPA to CGPA converter?",
      answer:
        "Our converter uses standard mathematical formulas for converting between different grading scales. The basic conversion formula is: New Scale GPA = (Your GPA × New Scale Maximum) ÷ Old Scale Maximum. This provides accurate conversions for most standard cases. For special cases, we offer custom formula options with adjustable parameters.",
    },
    {
      question: "Which grading scales does your converter support?",
      answer:
        "Our converter supports the most common grading scales used worldwide: 4.0 scale (US), 5.0 scale (Nigeria and some other countries), 10.0 scale (India and some European countries), and 20.0 scale (France). You can convert between any of these scales.",
    },
    {
      question: "Can I convert multiple GPA values at once?",
      answer:
        "Yes! Our batch conversion feature allows you to convert multiple GPA values simultaneously. Simply switch to the 'Batch Conversion' tab, enter your GPA values (one per line), and convert them all at once. You can also download the results as a CSV file.",
    },
    {
      question: "How do I use the custom formula option?",
      answer:
        "To use a custom formula, enable 'Show Advanced Options' and then toggle 'Use Custom Formula'. You can then set a custom multiplier and offset for your conversion. The formula used will be: (GPA × Multiplier) + Offset. This is useful for specialized conversions or when you know the exact conversion parameters needed.",
    },
    {
      question: "What does the chart visualization show?",
      answer:
        "The chart visualization displays the linear relationship between your source GPA scale and the target CGPA scale. It shows your specific conversion point on this line, helping you understand where your grades fall within both systems. This visual representation makes it easier to grasp the relative position of your grades.",
    },
    {
      question: "Can I save my conversion history?",
      answer:
        "Yes! Our tool automatically saves your recent conversions in your browser. You can view your conversion history by clicking 'Show History' at the bottom of the converter. You can also save this history as a JSON file for future reference by clicking 'Save History'.",
    },
    {
      question: "How do letter grades correspond to GPA values?",
      answer:
        "While this varies by institution, our tool uses a general approximation: A (90-100%), B (80-89%), C (70-79%), D (60-69%), and F (below 60%). When you convert your GPA, we'll show the corresponding letter grade based on the percentage equivalent of your result on the target scale.",
    },
    {
      question: "Is my data secure when using this converter?",
      answer:
        "Yes, all calculations are performed locally in your browser. We don't store or transmit your GPA data to any server. Your conversion history is stored only in your browser's local storage and is not accessible to us or any third parties.",
    },
    {
      question: "Can I use this converter on my mobile device?",
      answer:
        "Our GPA to CGPA converter is fully responsive and works on all devices including smartphones, tablets, laptops, and desktop computers. The interface automatically adjusts to provide the best experience on your specific device.",
    },
    {
      question: "How can I report an issue or suggest a feature?",
      answer:
        "We welcome your feedback! Please visit our Contact page to report any issues or suggest new features. We're constantly working to improve our tools based on user feedback.",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-theme-700 to-theme-600 text-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                Frequently Asked Questions
              </h1>
              <p className="mx-auto max-w-[700px] text-white/80 md:text-xl">
                Find answers to common questions about GPA to CGPA conversion and using our tools.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-3xl space-y-8">
            {/* Ad Space - Top */}
            <div className="w-full h-[120px] bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center mb-8 border-2 border-dashed border-gray-300 dark:border-gray-700">
              <p className="text-gray-500 dark:text-gray-400 text-sm">Advertisement Space</p>
            </div>

            <Accordion type="single" collapsible className="w-full">
              {faqItems.map((item, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left font-medium text-lg">{item.question}</AccordionTrigger>
                  <AccordionContent className="text-gray-600 dark:text-gray-300">{item.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>

            {/* Ad Space - Bottom */}
            <div className="w-full h-[120px] bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center mt-8 border-2 border-dashed border-gray-300 dark:border-gray-700">
              <p className="text-gray-500 dark:text-gray-400 text-sm">Advertisement Space</p>
            </div>

            <div className="text-center pt-8">
              <h2 className="text-2xl font-bold mb-4">Still have questions?</h2>
              <p className="text-gray-500 dark:text-gray-400 mb-6">
                If you couldn't find the answer to your question, feel free to contact us.
              </p>
              <Button asChild>
                <Link href="/contact">
                  Contact Us <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

